import { useMemo, useState } from "react";
import {
  Activity, ArrowDownRight, ArrowUpRight, BriefcaseBusiness, ChartNoAxesCombined,
  ChevronRight, CircleHelp, Command, Compass, CreditCard, Gauge, GraduationCap,
  LayoutDashboard, Menu, MessageCircle, Plus, Send, Settings2, ShieldCheck,
  Sparkles, Wallet, X
} from "lucide-react";

const money = (n) => new Intl.NumberFormat("en-IN", {
  style: "currency", currency: "INR", maximumFractionDigits: 0
}).format(Number(n || 0));

const navItems = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "budget", label: "Budget planner", icon: Wallet },
  { id: "business", label: "Business ideas", icon: BriefcaseBusiness },
  { id: "markets", label: "Market watch", icon: ChartNoAxesCombined },
  { id: "learn", label: "Learn", icon: GraduationCap }
];

function Logo() {
  return <div className="brand-mark" aria-label="Meteore 360 logo">
    <svg viewBox="0 0 40 40" role="img" aria-hidden="true">
      <defs><linearGradient id="meteorGradient" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stopColor="#8bdcff"/><stop offset="100%" stopColor="#6e78ff"/>
      </linearGradient></defs>
      <circle cx="20" cy="20" r="17" fill="none" stroke="url(#meteorGradient)" strokeWidth="1.7" opacity=".65"/>
      <path d="M10 26 23 10 20 20 30 16 17 31 19 22Z" fill="url(#meteorGradient)"/>
      <circle cx="29" cy="9" r="2" fill="#a7e9ff"/>
    </svg>
  </div>;
}

function StatCard({ title, value, note, icon: Icon, trend }) {
  return <div className="stat-card">
    <div className="stat-top"><span>{title}</span><span className="stat-icon"><Icon size={17}/></span></div>
    <div className="stat-value">{value}</div>
    <div className={`stat-note ${trend === "down" ? "muted" : "positive"}`}>
      {trend === "down" ? <ArrowDownRight size={15}/> : <ArrowUpRight size={15}/>} {note}
    </div>
  </div>;
}

export default function App() {
  const [active, setActive] = useState("overview");
  const [mobileNav, setMobileNav] = useState(false);
  const [income, setIncome] = useState("30000");
  const [expenses, setExpenses] = useState("18000");
  const [savings, setSavings] = useState("50000");
  const [goal, setGoal] = useState("Build an emergency fund");
  const [chatInput, setChatInput] = useState("");
  const [messages, setMessages] = useState([
    { role: "assistant", text: "Hey! I’m your Meteore companion. I can help you plan a budget, explore business ideas, and understand money concepts. What would you like to work on?" }
  ]);
  const [businessType, setBusinessType] = useState("Online service");
  const [businessBudget, setBusinessBudget] = useState("5000");
  const [businessResult, setBusinessResult] = useState(false);
  const [showPlans, setShowPlans] = useState(false);
  const [upgradePrompt, setUpgradePrompt] = useState(true);

  function requestPlan(planName, price) {
    const message = `Hi, I want to subscribe to the ${planName} plan of Meteore AI (${price}). Please share the official payment details and subscription terms.`;
    // This opens WhatsApp to request payment instructions; it does not process payments.
    window.open(`https://wa.me/917579203707?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
  }

  const balance = Math.max(0, Number(income || 0) - Number(expenses || 0));
  const savingsRate = Number(income) > 0 ? Math.min(100, Math.round((balance / Number(income)) * 100)) : 0;
  const runway = Number(expenses) > 0 ? (Number(savings) / Number(expenses)).toFixed(1) : "—";

  const pageTitle = navItems.find((item) => item.id === active)?.label || "Overview";
  const tips = useMemo(() => {
    const amount = Number(businessBudget || 0);
    if (amount <= 2000) return ["Offer a simple service using free tools", "Start with one clear customer problem", "Get 3 test customers before paying for software"];
    if (amount <= 10000) return ["Validate demand before buying inventory", "Reserve at least 30% for unexpected costs", "Try a small pilot with a measurable result"];
    return ["Split the budget into testing, delivery, and a reserve", "Compare 2–3 suppliers before committing", "Track customer acquisition cost from day one"];
  }, [businessBudget]);

  function sendMessage(e) {
    e.preventDefault();
    const text = chatInput.trim();
    if (!text) return;
    setMessages((old) => [...old, { role: "user", text },
      { role: "assistant", text: "This starter version is running in demo mode, so I can’t contact an AI model yet. Your next step is to connect a secure server-side AI endpoint—never place an API key in this React code. For now, try Budget Planner, Business Ideas, or Learn for working local tools." }]);
    setChatInput("");
  }

  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
      <div className="brand-row"><Logo/><div><div className="brand-name">METEORE <span>360</span></div><div className="brand-caption">INTELLIGENCE WITHOUT LIMITS</div></div><button className="icon-btn close-nav" onClick={() => setMobileNav(false)} aria-label="Close menu"><X size={18}/></button></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav className="main-nav">
        {navItems.map(({ id, label, icon: Icon }) => <button key={id} className={`nav-item ${active === id ? "active" : ""}`} onClick={() => { setActive(id); setMobileNav(false); }}>
          <Icon size={18}/><span>{label}</span>{active === id && <span className="nav-dot"/>}
        </button>)}
      </nav>
      <div className="sidebar-bottom">
        <div className="upgrade-card"><div className="upgrade-icon"><Sparkles size={17}/></div><strong>Your next move starts here.</strong><p>Make clearer money and business decisions, one step at a time.</p><button onClick={() => setActive("learn")}>Explore learning <ChevronRight size={15}/></button></div>
        <button className="nav-item settings" onClick={() => alert("Settings can be added in the next build.")}><Settings2 size={18}/><span>Settings</span></button>
        <div className="profile-row"><div className="avatar">M</div><div className="profile-copy"><strong>Meteore Member</strong><span>Personal workspace</span></div><CircleHelp size={17} className="help-icon"/></div>
      </div>
    </aside>

    {mobileNav && <button className="scrim" onClick={() => setMobileNav(false)} aria-label="Close navigation"/>}
    <main className="main-area">
      <header className="topbar"><button className="icon-btn menu-btn" onClick={() => setMobileNav(true)} aria-label="Open menu"><Menu size={20}/></button><div className="breadcrumb">Meteore AI <span>/</span> {pageTitle}</div><div className="topbar-right"><span className="status-dot"/> <span className="status-text">Personal finance workspace</span><button className="command-btn" onClick={() => setShowPlans(true)}><Sparkles size={14}/> <span>Plans</span></button><button className="command-btn" onClick={() => setActive("overview")}><Command size={14}/> <span>Home</span></button></div></header>

      <div className="content-wrap">
        {active === "overview" && <>
          <section className="welcome-row"><div><div className="eyebrow"><Sparkles size={14}/> YOUR PERSONAL MONEY COMPANION</div><h1>Make your next move <span>count.</span></h1><p className="subtitle">A clearer view of your money, ideas, and what to do next.</p></div><div className="date-pill"><Activity size={15}/> Your workspace</div></section>
          <section className="hero-card"><div className="hero-orb orb-one"/><div className="hero-orb orb-two"/><div className="hero-content"><div className="hero-kicker"><span className="tiny-star">✦</span> METEORE INTELLIGENCE</div><h2>Big goals. <span>Smarter steps.</span></h2><p>Turn uncertainty into a plan with practical money tools and business guidance.</p><button className="primary-btn" onClick={() => setActive("budget")}>Build my plan <ChevronRight size={17}/></button></div><div className="hero-art"><div className="orbit orbit-a"/><div className="orbit orbit-b"/><div className="planet"><Logo/></div><span className="orbit-dot dot-a"/><span className="orbit-dot dot-b"/><span className="orbit-dot dot-c"/></div></section>
          {upgradePrompt && <section className="upgrade-banner"><div className="upgrade-banner-icon"><Sparkles size={18}/></div><div className="upgrade-banner-copy"><strong>Need more from your money companion?</strong><p>Compare Meteore plans and choose what fits you. This reminder can be dismissed.</p></div><button className="upgrade-banner-btn" onClick={() => setShowPlans(true)}>View plans <ChevronRight size={15}/></button><button className="dismiss-btn" onClick={() => setUpgradePrompt(false)} aria-label="Dismiss upgrade message"><X size={16}/></button></section>}
          <div className="section-heading"><div><h2>Your snapshot</h2><p>Example numbers to help you explore the planner.</p></div><span className="demo-badge">DEMO DATA</span></div>
          <section className="stats-grid">
            <StatCard title="Monthly income" value={money(income)} note="Editable in Budget Planner" icon={Wallet}/>
            <StatCard title="Monthly spending" value={money(expenses)} note="Keep an eye on essentials" icon={CreditCard} trend="down"/>
            <StatCard title="Monthly surplus" value={money(balance)} note={`${savingsRate}% of income left`} icon={Gauge}/>
            <StatCard title="Savings runway" value={`${runway} months`} note="Savings ÷ monthly spending" icon={Activity}/>
          </section>
          <div className="dashboard-grid"><section className="panel assistant-panel"><div className="panel-heading"><div className="panel-title-icon"><Sparkles size={17}/></div><div><h3>Ask Meteore</h3><p>Your money and business companion</p></div><span className="demo-badge">PREVIEW</span></div><div className="chat-messages">{messages.slice(-3).map((m, i) => <div key={i} className={`chat-line ${m.role}`}><div className="chat-avatar">{m.role === "assistant" ? <Logo/> : "Y"}</div><div className="chat-bubble">{m.text}</div></div>)}</div><form className="chat-form" onSubmit={sendMessage}><input value={chatInput} onChange={(e) => setChatInput(e.target.value)} placeholder="Ask about budgeting, business, or money…" aria-label="Ask Meteore"/><button className="send-btn" type="submit" aria-label="Send message"><Send size={17}/></button></form><div className="privacy-note"><ShieldCheck size={13}/> Demo mode · No financial account connected</div></section>
          <section className="panel quick-panel"><div className="panel-heading"><div><h3>Quick actions</h3><p>Choose a place to start</p></div></div><button className="action-row" onClick={() => setActive("budget")}><span className="action-icon blue"><Wallet size={18}/></span><span><strong>Plan my monthly budget</strong><small>See what you can save</small></span><ChevronRight size={17}/></button><button className="action-row" onClick={() => setActive("business")}><span className="action-icon purple"><BriefcaseBusiness size={18}/></span><span><strong>Explore a business idea</strong><small>Start with your budget</small></span><ChevronRight size={17}/></button><button className="action-row" onClick={() => setActive("markets")}><span className="action-icon green"><ChartNoAxesCombined size={18}/></span><span><strong>Understand the markets</strong><small>Educational watchlist</small></span><ChevronRight size={17}/></button><button className="action-row" onClick={() => setActive("learn")}><span className="action-icon amber"><GraduationCap size={18}/></span><span><strong>Learn a money concept</strong><small>Build your confidence</small></span><ChevronRight size={17}/></button></section></div>
          <footer className="footer">METEORE 360 <span>·</span> Built for clearer decisions. <span className="footer-right">Educational tool only — not financial advice.</span></footer>
        </>}

        {active === "budget" && <section className="page-section"><div className="eyebrow"><Wallet size={14}/> MONEY PLANNER</div><h1>Know where your money goes.</h1><p className="subtitle">Adjust the figures below to create a simple monthly snapshot. Your numbers stay in this browser session.</p><div className="planner-grid"><div className="panel form-panel"><h3>Monthly money</h3><label>Monthly income (₹)<input type="number" min="0" value={income} onChange={e => setIncome(e.target.value)}/></label><label>Monthly expenses (₹)<input type="number" min="0" value={expenses} onChange={e => setExpenses(e.target.value)}/></label><label>Current savings (₹)<input type="number" min="0" value={savings} onChange={e => setSavings(e.target.value)}/></label><label>My current goal<input value={goal} onChange={e => setGoal(e.target.value)} placeholder="e.g. Emergency fund"/></label></div><div className="panel results-panel"><div className="eyebrow">YOUR ESTIMATE</div><h2>{money(balance)} <small>/ month</small></h2><p className="muted-text">Estimated money left after monthly expenses</p><div className="progress-label"><span>Savings rate</span><strong>{savingsRate}%</strong></div><div className="progress-track"><div className="progress-fill" style={{width: `${savingsRate}%`}}/></div><div className="result-line"><span>Current savings</span><strong>{money(savings)}</strong></div><div className="result-line"><span>Runway at this spending level</span><strong>{runway} months</strong></div><div className="goal-box"><Sparkles size={17}/><div><strong>Your goal</strong><p>{goal || "Add a goal to get focused."}</p></div></div><p className="disclaimer">Estimates only. This does not account for debt, taxes, irregular expenses, inflation, or investment returns.</p></div></div></section>}

        {active === "business" && <section className="page-section"><div className="eyebrow"><BriefcaseBusiness size={14}/> BUSINESS LAUNCHPAD</div><h1>Start small. Validate first.</h1><p className="subtitle">Get a starter checklist based on the business type and budget you choose.</p><div className="planner-grid"><div className="panel form-panel"><h3>Your starting point</h3><label>Business type<select value={businessType} onChange={e => {setBusinessType(e.target.value); setBusinessResult(false);}}><option>Online service</option><option>AI website or app</option><option>Digital products</option><option>Local service</option><option>Physical products</option></select></label><label>Starting budget (₹)<input type="number" min="0" value={businessBudget} onChange={e => {setBusinessBudget(e.target.value); setBusinessResult(false);}}/></label><button className="primary-btn full-btn" onClick={() => setBusinessResult(true)}>Create my starter plan <ChevronRight size={17}/></button></div><div className="panel results-panel"><div className="eyebrow">YOUR STARTER CHECKLIST</div><h2>{businessType}</h2><p className="muted-text">Suggested first steps for a {money(businessBudget)} budget.</p><ol className="check-list"><li><span>01</span><div><strong>Define one customer problem</strong><p>Write down who has the problem, how often it happens, and what they do today.</p></div></li><li><span>02</span><div><strong>Test before you spend</strong><p>Talk to 5 potential customers and show a simple mock-up or sample.</p></div></li><li><span>03</span><div><strong>Make a tiny first offer</strong><p>Try to get one real customer before expanding the product.</p></div></li>{tips.map((tip, i) => <li key={tip}><span>{String(i+4).padStart(2,"0")}</span><div><strong>{tip}</strong><p>Keep the first experiment low-cost and measurable.</p></div></li>)}</ol>{businessResult && <div className="success-note"><Sparkles size={16}/> Starter checklist refreshed for your selected budget.</div>}</div></div></section>}

        {active === "markets" && <section className="page-section"><div className="eyebrow"><ChartNoAxesCombined size={14}/> MARKET LEARNING</div><h1>Research before you react.</h1><p className="subtitle">A watchlist-style learning space. Prices below are illustrative placeholders, not live market data.</p><div className="panel market-panel"><div className="panel-heading"><div><h3>Market watchlist</h3><p>Illustrative examples only · No trading functionality</p></div><span className="demo-badge">NOT LIVE</span></div><div className="market-row"><div className="ticker-symbol">N</div><div className="ticker-copy"><strong>NIFTY 50</strong><small>Indian equity index · example only</small></div><div className="ticker-price">—</div><span className="market-tag">Connect data source</span></div><div className="market-row"><div className="ticker-symbol">S</div><div className="ticker-copy"><strong>SENSEX</strong><small>Indian equity index · example only</small></div><div className="ticker-price">—</div><span className="market-tag">Connect data source</span></div><div className="market-row"><div className="ticker-symbol">G</div><div className="ticker-copy"><strong>Gold</strong><small>Commodity · example only</small></div><div className="ticker-price">—</div><span className="market-tag">Connect data source</span></div><div className="market-note"><ShieldCheck size={16}/><p>For real prices, connect a reliable market-data provider through a backend and show its source and timestamp. This app does not provide buy/sell recommendations.</p></div></div><div className="learn-grid"><div className="panel"><span className="learn-number">01</span><h3>Understand risk</h3><p>Returns are uncertain. Learn the difference between volatility, risk capacity, and your time horizon.</p></div><div className="panel"><span className="learn-number">02</span><h3>Diversification</h3><p>Learn why concentrating all your money in one asset can increase risk.</p></div><div className="panel"><span className="learn-number">03</span><h3>Long-term thinking</h3><p>Compare fees, taxes, time horizon, and goals before making a financial decision.</p></div></div></section>}

        {active === "learn" && <section className="page-section"><div className="eyebrow"><GraduationCap size={14}/> METEORE ACADEMY</div><h1>Build your money intelligence.</h1><p className="subtitle">Short, practical concepts to help you ask better questions and make informed decisions.</p><div className="learn-grid"><div className="panel learning-card"><div className="action-icon blue"><Wallet size={20}/></div><h3>Budgeting basics</h3><p>Give every rupee a purpose, track recurring expenses, and review your plan monthly.</p><button className="text-btn" onClick={() => setActive("budget")}>Try the budget planner <ChevronRight size={15}/></button></div><div className="panel learning-card"><div className="action-icon purple"><BriefcaseBusiness size={20}/></div><h3>Validate a business</h3><p>Customer conversations and small tests can reduce the chance of building something nobody needs.</p><button className="text-btn" onClick={() => setActive("business")}>Build a starter checklist <ChevronRight size={15}/></button></div><div className="panel learning-card"><div className="action-icon green"><ChartNoAxesCombined size={20}/></div><h3>Investing foundations</h3><p>Learn about diversification, risk, fees, and why past performance cannot guarantee future results.</p><button className="text-btn" onClick={() => setActive("markets")}>Explore market learning <ChevronRight size={15}/></button></div></div><div className="panel safety-panel"><ShieldCheck size={20}/><div><h3>Keep decisions grounded</h3><p>Meteore AI is an educational planning tool, not a registered investment adviser. Verify important information with qualified professionals and official sources before acting.</p></div></div></section>}
      </div>
      {showPlans && <div className="modal-backdrop" role="presentation" onClick={(e) => { if (e.target === e.currentTarget) setShowPlans(false); }}>
        <section className="plans-modal" role="dialog" aria-modal="true" aria-labelledby="plans-title">
          <div className="plans-modal-head"><div><div className="eyebrow"><Sparkles size={14}/> METEORE MEMBERSHIPS</div><h2 id="plans-title">Choose your level.</h2><p>Start free. Upgrade when you need more.</p></div><button className="icon-btn" onClick={() => setShowPlans(false)} aria-label="Close plans"><X size={18}/></button></div>
          <div className="pricing-grid">
            <article className="pricing-card"><div className="plan-name">Basic</div><div className="plan-price">Free <span>forever</span></div><p className="plan-desc">For exploring your money and business basics.</p><ul><li>Budget planner</li><li>Business starter checklist</li><li>Financial learning guides</li><li>Demo chat experience</li></ul><button className="plan-btn secondary-plan" onClick={() => setShowPlans(false)}>Current free plan</button></article>
            <article className="pricing-card featured-plan"><div className="popular-label">MOST POPULAR</div><div className="plan-name">Medium</div><div className="plan-price">$200 <span>/ month</span></div><p className="plan-desc">For people building more detailed money and business plans.</p><ul><li>Everything in Basic</li><li>Expanded planning tools</li><li>Business planning workspace</li><li>Priority feature access (planned)</li></ul><button className="plan-btn primary-plan" onClick={() => requestPlan("Medium", "$200/month")}>Request subscription <ChevronRight size={16}/></button></article>
            <article className="pricing-card"><div className="plan-name">High</div><div className="plan-price">$300 <span>/ month</span></div><p className="plan-desc">For power users who want the most advanced tier.</p><ul><li>Everything in Medium</li><li>Advanced workflows (planned)</li><li>Deeper business analysis (planned)</li><li>Early access to new features</li></ul><button className="plan-btn secondary-plan" onClick={() => requestPlan("High", "$300/month")}>Request subscription <ChevronRight size={16}/></button></article>
          </div>
          <div className="payment-note"><ShieldCheck size={16}/><p><strong>Payment setup:</strong> this button opens WhatsApp to request payment instructions at the contact number you provided. It does not charge, confirm, or activate a subscription automatically. Add a payment gateway and server-side payment verification before selling subscriptions. Prices shown are USD per month; confirm currency, taxes, refunds, and terms before launch.</p></div>
        </section>
      </div>}
    </main>
  </div>;
}