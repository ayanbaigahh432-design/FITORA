# Meteore 360 — Meteore AI starter

A responsive React + Vite starter for a personal money and business companion. It uses a dark, premium dashboard design and includes local demo tools:
- Monthly budget calculator and savings runway estimate
- Business starter checklist
- Investing education and a clearly marked non-live watchlist
- Demo chat UI (not connected to an AI model yet)

## Important limitations
- Dashboard figures are sample/demo values until you enter your own.
- Market watch is **not live data**. Do not present placeholder values as real market prices.
- Chat is demo mode. To use an AI model, create a backend API endpoint and keep provider keys in server-side environment variables. Never put API keys in `src/`, frontend environment variables prefixed with `VITE_`, or a public GitHub repository.
- This is an educational planning tool, not financial advice. Do not add automated trading or personalized buy/sell recommendations without appropriate legal and compliance review.

## Run on your computer
1. Install Node.js LTS from https://nodejs.org/
2. Extract this ZIP.
3. Open a terminal in the extracted `meteore-360-starter` folder.
4. Run:
   ```bash
   npm install
   npm run dev
   ```
5. Open the local URL printed in the terminal (usually `http://localhost:5173`).

## Build check
```bash
npm run build
```
Vite creates a production build in `dist/`.

## Publish to GitHub (beginner route)
1. Sign in to https://github.com/
2. Click **+ → New repository**.
3. Name it `meteore-360`; choose Public or Private; do not upload any API keys.
4. Create the repository.
5. On the repository page, click **Add file → Upload files**.
6. Extract this ZIP on your computer and upload the *contents* of the `meteore-360-starter` folder (upload `package.json`, `index.html`, `src/`, and `README.md`; do not upload the ZIP itself).
7. Click **Commit changes**.

## Deploy to Netlify
1. Sign in to https://www.netlify.com/ and choose **Add new site → Import an existing project**.
2. Connect GitHub and choose `meteore-360`.
3. Build command: `npm run build`
4. Publish directory: `dist`
5. Click deploy. For this frontend-only demo, no environment variables are needed.

## Before launch
- Replace sample numbers with clearly labelled user inputs or stored preferences.
- Add authentication and privacy controls if storing personal financial data.
- Connect AI only through a secure server endpoint.
- Connect a licensed/appropriate market data provider for real prices, with timestamps and attribution.
- Add tests, error states, and mobile testing.


## Subscription UI (demo)
The app includes Basic (Free), Medium ($200/month), and High ($300/month) plan cards. Upgrade prompts are dismissible rather than repeatedly interrupting users. Paid-plan buttons open WhatsApp to the supplied contact number to request payment instructions. They do not take payments or activate plans automatically. Before charging customers, set up a legitimate payment provider, server-side verification, clear billing terms, refunds/cancellation, and access control. Do not treat a WhatsApp message as proof of payment.
