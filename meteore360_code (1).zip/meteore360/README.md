# 🌌 Meteore 360 — AI Financial & Business Operations

> **Meteore 360 by AYAN BAIG**

## Features
- Pure Dark Theme with Space Intro Animation
- Interactive Haptic Sound Feedback on Clicks
- AI Chatbot with Systematic Chart Form Allocator
- Business, Investments, Stocks, Skills Hub & Pro Subscriptions (~₹200 / ₹400)
- UPI Payment Direct Link: `7579203707`

## Setup
```bash
npm install
npm run dev
```
