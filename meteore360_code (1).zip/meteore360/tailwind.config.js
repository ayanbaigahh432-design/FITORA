/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        darkBg: "#000000",
        cardBg: "#0D0D0D",
        cardBorder: "#1A1A1A",
      },
    },
  },
  plugins: [],
}
