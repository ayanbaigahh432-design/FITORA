import React, { useState } from 'react';
import { playClickSound } from '../audio/soundPlayer';
import SystematicChart from '../dynamicForms/SystematicChart';

export default function MeteoreChatbot() {
  const [messages, setMessages] = useState([
    { sender: 'ai', text: 'Welcome to Meteore 360 AI Engine. How can I structure your startup or manage your savings today?' }
  ]);
  const [input, setInput] = useState('');

  const handleSend = (e) => {
    e.preventDefault();
    if (!input.trim()) return;
    playClickSound();

    const userText = input;
    setMessages(prev => [...prev, { sender: 'user', text: userText }]);
    setInput('');

    setTimeout(() => {
      let aiResponse = "I have analyzed your input using web and market intelligence references.";
      if (userText.includes('5000') || userText.toLowerCase().includes('savings') || userText.toLowerCase().includes('rupay')) {
        aiResponse = "Here is your systematic budget allocation plan for your savings:";
      }
      setMessages(prev => [...prev, { sender: 'ai', text: aiResponse }]);
    }, 600);
  };

  return (
    <div className="bg-[#0D0D0D] border border-[#1A1A1A] rounded-xl p-4 flex flex-col h-[500px]">
      <div className="flex-1 overflow-y-auto space-y-4 pr-2">
        {messages.map((msg, index) => (
          <div key={index} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] rounded-lg p-3 text-sm ${msg.sender === 'user' ? 'bg-white text-black font-medium' : 'bg-black border border-[#1A1A1A] text-white'}`}>
              <p>{msg.text}</p>
              {(msg.text.includes('5000') || msg.text.includes('systematic budget')) && <SystematicChart />}
            </div>
          </div>
        ))}
      </div>
      <form onSubmit={handleSend} className="mt-4 flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask AI, e.g. 'Mere paas 5000 rupay hai' or startup details..."
          className="flex-1 bg-black border border-[#1A1A1A] rounded-lg px-4 py-2 text-white focus:outline-none focus:border-white text-sm"
        />
        <button
          type="submit"
          onClick={() => playClickSound()}
          className="bg-white text-black px-5 py-2 rounded-lg text-sm font-semibold hover:bg-gray-200"
        >
          Send
        </button>
      </form>
    </div>
  );
}
