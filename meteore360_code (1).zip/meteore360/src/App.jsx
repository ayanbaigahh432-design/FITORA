import React, { useState } from 'react';
import SpaceIntro from './components/SpaceIntro';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import MeteoreChatbot from './chatbot/MeteoreChatbot';
import SystematicChart from './dynamicForms/SystematicChart';
import { playClickSound } from './audio/soundPlayer';

export default function App() {
  const [introFinished, setIntroFinished] = useState(false);
  const [activeTab, setActiveTab] = useState('home');

  return (
    <>
      {!introFinished && <SpaceIntro onComplete={() => setIntroFinished(true)} />}
      <div className="min-h-screen bg-black text-white flex flex-col justify-between">
        <div>
          <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
          
          <main className="max-w-6xl mx-auto px-4 py-8">
            {activeTab === 'home' && (
              <div className="space-y-8">
                <div className="text-center space-y-3">
                  <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight">360° AI Command Center</h1>
                  <p className="text-gray-400 max-w-2xl mx-auto">
                    Manage startups, automate shop & hotel billing, analyze stocks, and optimize student savings with Meteore 360.
                  </p>
                </div>
                <SystematicChart />
                <MeteoreChatbot />
              </div>
            )}

            {activeTab === 'business' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold">Business & Startup Setup</h2>
                <div className="bg-[#0D0D0D] border border-[#1A1A1A] p-6 rounded-xl">
                  <p className="text-gray-300 mb-4">AI Web Scanner & Location Radar connected for market insights and direct competitor references.</p>
                  <MeteoreChatbot />
                </div>
              </div>
            )}

            {activeTab === 'investments' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold">Plans of Investment</h2>
                <SystematicChart />
              </div>
            )}

            {activeTab === 'stocks' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold">Shares & Stocks Radar</h2>
                <div className="bg-[#0D0D0D] border border-[#1A1A1A] p-6 rounded-xl text-center">
                  <p className="text-gray-400">Live AI Stock Market Indicators & Risk Analysis Active.</p>
                </div>
              </div>
            )}

            {activeTab === 'skills' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold">Meteore Skills Hub (₹400 Plan)</h2>
                <div className="bg-[#0D0D0D] border border-[#1A1A1A] p-6 rounded-xl">
                  <p className="text-gray-300">Master financial modeling, startup equity, and AI tool operations.</p>
                </div>
              </div>
            )}

            {activeTab === 'subscriptions' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold">Pro Subscriptions & Automation Access</h2>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-[#0D0D0D] border border-[#1A1A1A] p-6 rounded-xl space-y-4">
                    <h3 className="text-xl font-bold text-white">Meteore Pro (~₹200/mo)</h3>
                    <p className="text-sm text-gray-400">For Hotels, Shops & Businesses. Automated billing, online order management, and vendor payment execution.</p>
                    <div className="p-3 bg-black border border-[#1A1A1A] rounded text-xs text-gray-300">
                      Direct UPI/PhonePe Payment: <span className="font-bold text-white">7579203707</span>
                    </div>
                  </div>
                  <div className="bg-[#0D0D0D] border border-[#1A1A1A] p-6 rounded-xl space-y-4">
                    <h3 className="text-xl font-bold text-white">Meteore Skills Plan (₹400)</h3>
                    <p className="text-sm text-gray-400">Complete guided AI execution modules for founders & students.</p>
                    <div className="p-3 bg-black border border-[#1A1A1A] rounded text-xs text-gray-300">
                      Direct UPI/PhonePe Payment: <span className="font-bold text-white">7579203707</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </main>
        </div>
        <Footer />
      </div>
    </>
  );
}
