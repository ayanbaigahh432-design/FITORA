import React, { useState } from 'react';
import { playClickSound } from '../audio/soundPlayer';

export default function SystematicChart() {
  const [amount, setAmount] = useState('5000');
  const [plan, setPlan] = useState(null);

  const calculatePlan = (e) => {
    e.preventDefault();
    playClickSound();
    const num = parseFloat(amount) || 0;
    setPlan({
      emergency: (num * 0.20).toFixed(2),
      investment: (num * 0.30).toFixed(2),
      skills: (num * 0.30).toFixed(2),
      dailyExpenses: (num * 0.20).toFixed(2),
    });
  };

  return (
    <div className="bg-[#0D0D0D] border border-[#1A1A1A] rounded-xl p-6 my-6 shadow-2xl">
      <h3 className="text-xl font-bold mb-2 text-white">Systematic AI Financial Allocator</h3>
      <p className="text-sm text-gray-400 mb-4">Enter your savings/starting capital to generate an automated execution chart.</p>
      
      <form onSubmit={calculatePlan} className="flex gap-3 mb-6">
        <div className="relative flex-1">
          <span className="absolute left-3 top-2.5 text-gray-500">₹</span>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-full bg-black border border-[#1A1A1A] rounded-lg py-2 pl-8 pr-4 text-white focus:outline-none focus:border-white transition-all"
            placeholder="e.g. 5000"
          />
        </div>
        <button
          type="submit"
          onClick={() => playClickSound()}
          className="bg-white text-black px-6 py-2 rounded-lg font-semibold hover:bg-gray-200 transition-all"
        >
          Generate Plan
        </button>
      </form>

      {plan && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 animate-fade-in">
          <div className="bg-black border border-[#1A1A1A] p-4 rounded-lg">
            <span className="text-xs text-gray-400">Emergency Reserve (20%)</span>
            <p className="text-xl font-bold mt-1 text-emerald-400">₹{plan.emergency}</p>
          </div>
          <div className="bg-black border border-[#1A1A1A] p-4 rounded-lg">
            <span className="text-xs text-gray-400">Micro-Investment (30%)</span>
            <p className="text-xl font-bold mt-1 text-blue-400">₹{plan.investment}</p>
          </div>
          <div className="bg-black border border-[#1A1A1A] p-4 rounded-lg">
            <span className="text-xs text-gray-400">Meteore Skills (30%)</span>
            <p className="text-xl font-bold mt-1 text-purple-400">₹{plan.skills}</p>
          </div>
          <div className="bg-black border border-[#1A1A1A] p-4 rounded-lg">
            <span className="text-xs text-gray-400">Daily Burn Cap (20%)</span>
            <p className="text-xl font-bold mt-1 text-amber-400">₹{plan.dailyExpenses}</p>
          </div>
        </div>
      )}
    </div>
  );
}
