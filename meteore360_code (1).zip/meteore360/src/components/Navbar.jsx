import React from 'react';
import { playClickSound } from '../audio/soundPlayer';

export default function Navbar({ activeTab, setActiveTab }) {
  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'business', label: 'Business' },
    { id: 'investments', label: 'Plans of Investment' },
    { id: 'stocks', label: 'Shares & Stocks' },
    { id: 'skills', label: 'Meteore Skills' },
    { id: 'subscriptions', label: 'Pro & Subscriptions' }
  ];

  const handleTabClick = (id) => {
    playClickSound();
    setActiveTab(id);
  };

  return (
    <nav className="sticky top-0 z-40 bg-black/80 backdrop-blur-md border-b border-[#1A1A1A] px-4 py-3 flex items-center justify-between">
      <div className="flex items-center space-x-2 cursor-pointer" onClick={() => handleTabClick('home')}>
        <div className="w-8 h-8 rounded-full border border-white flex items-center justify-center font-bold text-sm">
          360
        </div>
        <span className="font-bold text-lg tracking-wider text-white">METEORE 360</span>
      </div>
      <div className="hidden md:flex space-x-1">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => handleTabClick(item.id)}
            className={`px-3 py-1.5 rounded-md text-sm transition-all ${
              activeTab === item.id
                ? 'bg-white text-black font-semibold'
                : 'text-gray-400 hover:text-white hover:bg-[#1A1A1A]'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>
    </nav>
  );
}
