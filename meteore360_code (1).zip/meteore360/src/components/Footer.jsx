import React from 'react';

export default function Footer() {
  return (
    <footer className="border-t border-[#1A1A1A] py-6 text-center text-sm text-gray-400 bg-black">
      <p className="font-semibold text-white tracking-widest uppercase">Meteore 360 by AYAN BAIG</p>
      <p className="text-xs text-gray-600 mt-1">All rights reserved. Autonomous AI Business & Financial Operations.</p>
    </footer>
  );
}
