import React, { useEffect, useState } from 'react';

export default function SpaceIntro({ onComplete }) {
  const [fade, setFade] = useState(false);

  useEffect(() => {
    const timer1 = setTimeout(() => setFade(true), 2500);
    const timer2 = setTimeout(() => onComplete(), 3000);
    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, [onComplete]);

  return (
    <div className={`fixed inset-0 z-50 bg-black flex flex-col items-center justify-center transition-opacity duration-500 ${fade ? 'opacity-0' : 'opacity-100'}`}>
      <div className="relative flex items-center justify-center">
        <div className="absolute w-64 h-64 border border-white/20 rounded-full animate-orbit"></div>
        <div className="absolute w-80 h-80 border border-white/10 rounded-full animate-orbit" style={{ animationDirection: 'reverse', animationDuration: '12s' }}></div>
        <div className="z-10 text-center">
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-widest text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.8)]">
            METEORE 360
          </h1>
          <p className="text-xs text-gray-400 tracking-widest mt-2 uppercase">AI Financial & Business Operations</p>
        </div>
      </div>
    </div>
  );
}
